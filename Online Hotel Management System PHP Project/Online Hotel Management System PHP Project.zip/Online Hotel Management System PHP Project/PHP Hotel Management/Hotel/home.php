<html>
<head>
	<title>home page</title>
	<link rel="stylesheet" type="text/css" href="link.html">
</head>
<body bgcolor="#fff2e5">

<?php
	include "index.php";
?>
<br>
<br>
	<center><font color=chocolate size=4><b><i><u>HOME</u></i></b></font></center>
	<br>

	<table>
	<tr>
		<td>&nbsp;</td>
		<td><font color="#7c0000"><b><i></i></b></font><center>
		  <font color="#7c0000"><b><i>HOTEL IN AMRELI:HOTEL PARAS
		</i></b></font>
		</center></td>
	</tr>
	<tr>
		<td><a href=h1.php target=_blank><img src="image/Leela-Hotel-Porters-LARGE.JPG" width=144 height=166></a></td>
		<td><font color=chocolate>		
						Hotel PARAS,among the premier
		business hotel in
						amreli the economic capital of
		saurashtra is 			
						characterised by the traditionally
		hospitality located
						in the heart of the city.The ideal
		choice amongs hotels
						in Amreli for businessman and
		tourist.</font></td>
		<td><a href=h2.php target=_blank><img src="image/hbusicent.jpg" width=125 height=150></a></td>
	</tr>
	<tr>
		<td><font color="#7c0000">Entry</font></td>
		<td></td>
		<td><font color="#7c0000">Reception</font></td>
	</tr>
	<tr>
		<td>&nbsp;</td>
		<td><font color=darkpink>
					The PARAS offers facilities that no 
		other Amreli hotels
					offer.Each room is elegantly well
		appointed and equipped
					with complete amenities including
		aircondition fully stock
					minibars,directIDD telephone,TV
		with 24 hour satelight
					entertainment and news.Upscale
		bathroom with hair dryers
					and cosmetic mirrors,seperate
		hanging closets.</font></td>
		<td></td>
	</tr>
	</table>
		<br><br>
	<table>
		<tr>
			<td><a href=h3.php target=_blank><img src="image/pic5.jpg" width=125 height=150></a></td>
			<td><font color=chocolate>
			The only one Amreli hotels having all facilities a business center,beauty parlor,health club,gym,saloon,
			boutique,internet cafe,pastry shop,travel desk and money exchange the PARAS hotels given you full value
			for money.</font></td>
			<td><a href=h4.php target=_blank><img src="image/hrooms.jpg" width=125 height=150></a></td>
		</tr>
		<tr>
			<td><font color="#7c0000">Main hall</font></td>
		<td></td>
			<td><font color="#7c0000">Lobby</font></td>
		</tr>
		<td></td>
		<td><font color=darkpink>
		Hotel PARAS takes pride in being a host to a number of celebrities,including bollywood and telewood starts,
		cricketers,political leaders as well as corporate borons and also being the most prefered in Amreli.By the NRIs.
		<td></td>
		</tr>
	</table>
    <marquee behavior=alternate bgcolor="#7e0000"><b><i><a href=contectus.php><font color="white">Devloped By :- Karthikh Venkat </a></i></b></font></marquee>
</body>
</html>
		



