<html>
<head>
	<title>superdeluxe1</title>
</head>
<body bgcolor="#fff2e5">
<?php include "room.php";
?>
	<h3 align=center><font color=chocolate>SUPERDELUXE ROOM</font></h3>
	<center><a href=superdeluxe.php><img src="image/hsuites.jpg" width=350 height=200></a></center>
<table border=0>
	<tr>
		<th><font size=4>Location:2<sup>nd</sup>floor</th>
	</tr>
	<tr>
		<th><font size=4>size:17<sup>'</sup>6<sup>"</sup>*12<sup>'</sup>00<sup>"</sup></th>
	</tr>
</table>
<br><br>
<table align=center>
	<tr>
		<td>
		<ul type=square>
			<li><font color="#7c0000" size=4>Room</font>
		<font color="choco">
		<ul type=disc>
			<li>Double/Twin bed.
			<li>Individually controolled air conditioning.
			<li>Direct access internet.
			<li>29<sup>th</sup>flat interactive television
			<li>Electronic door locks.
			<li>Satelight entertainment & new channels.
			<li>Fully stocked minibar.
			<li>Direct IDD telephone with voicemail.
			<li>Laptop compatiable digital safe.
			<li>Carpet flooring.
			<li>Data port on telephone.
			<li>Power socket on besides and desk.
			<li>Separate luggage area with luggage rack.
			<li>Daily complimentary newspaper.
			<li>Room locar facalities.
		</ul>
			<li><font color="#7c0000" size=4>Bathroom</font>
		<ul type=disc>
			<li>Ensuite bathroom.
			<li>Bath tubs.
			<li>Cosmetic mirror.
			<li>Hair dryer.
			<li>Weighing scale.
			<li>Power socket.
			<li>Running hot & cold water in showers.			
		</ul>
		</ul>
		</font></td></tr>
</table>
<a href=accommodation.php>home</a>
</body>
</html>

			
