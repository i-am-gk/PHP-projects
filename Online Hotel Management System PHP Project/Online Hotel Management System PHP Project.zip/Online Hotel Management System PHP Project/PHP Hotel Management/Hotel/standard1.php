<html>
<head>
	<title>standard1</title>
</head>
<body bgcolor="#fff2e5">
	<?php include "room.php"; ?>
	<h3 align=center><font color=chocolate>STANDARD ROOM</font></h3>
	<center><a href=standard.php><img src="image/piccolino_hotel_10.jpg" width=446 height=297></a>
	</center>
	<table border=0>
	<tr>
		<th><font size=4>Location:4<sup>th</sup>floor</th>
	</tr>
	<tr>
		<th><font size=4>size:12<sup>'</sup>00<sup>"</sup>*11<sup>'</sup>6<sup>"</sup></th>
	</tr>
	</table>
	<br><br>
	<table align=center>
	<tr>
		<td>
		<ul type=square>
			<li><font color="#7c0000" size=4>Room</font>
		<font color="choco">
		<ul type=disc>
			<li>Single/Twin bed.
			<li>Individually controlled air conditioning.
			<li>Direct access internet.
			<li>21<sup>th</sup>flat interactive television.
			<li>Electronic door locks.
			<li>Satelight entertainment & new channels.
			<li>Fully stocked minibar.
			<li>Direct IDD telephone with voicemail.		
			<li>Laptop compatible digital safe.
			<li>Tiles flooring.
			<li>Data port on telephone.
			<li>Power socket on besides and desk.
			<li>Separate luggage area with luggage rack.
			<li>Daily complimentary newspaper.
			<li>Room locar facalities.
		</ul>
		<li><font color="#7c0000" size=4>Bathroom</font>
		<ul type=disc>
			<li>ensuite bathroom.
			<li>Bath tubs.
			<li>Cosmetic mirror.
			<li>Hair dryer.
			<li>Weighing scale.
			<li>Power socket.
			<li>Running hot & cold water in showers.			
		</ul>
		</ul>
		</font></td></tr>
</table>
<a href=accommodation.php>home</a>
</body>
</html>
			
</html>