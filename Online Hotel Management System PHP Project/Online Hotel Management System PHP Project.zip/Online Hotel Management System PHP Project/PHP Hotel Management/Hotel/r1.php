<html>
<body>
	<img src="image/dining3.jpg" height=400 width=750>
</body>
</html>